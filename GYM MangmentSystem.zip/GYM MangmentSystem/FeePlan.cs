﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYM_MangmentSystem
{
    class FeePlan
    {
        private int id;
        private string name;
        private string amount;
        public int Id
        {
            set { id = value; }
            get { return id; }
        }
        public string Name
        {
            set { name = value; }
            get { return name; }
        }
        public string Amount
        {
            set { amount = value; }
            get { return amount; }
        }
    }
}
