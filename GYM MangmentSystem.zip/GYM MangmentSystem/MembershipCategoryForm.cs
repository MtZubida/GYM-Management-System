﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_MangmentSystem
{
    public partial class MembershipCategoryForm : Form
    {
        MembershipCatagory oc;
        SqlRunClass aj;
        string ac;
        public MembershipCategoryForm()
        {
            InitializeComponent();
            oc = new MembershipCatagory();
            aj = new SqlRunClass();
            ac = "select *from MembershipCategory";
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            oc.Id = int.Parse(textBoxID.Text);
            oc.Name = textBoxName.Text;
            string sqlText1 = @"insert into MembershipCategory([id]
             ,[name])
             values("+oc.Id+",'"+oc.Name+"')";
            aj.SqlExecute(sqlText1);
            dataGridView1.DataSource = aj.showme(ac);

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            oc.Id = int.Parse(textBoxID.Text);
            String sg = "Delete From MembershipCategory where id = " + oc.Id + "";
            aj.SqlExecute(sg);
            MessageBox.Show("ITEM DELETE");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            oc.Id = int.Parse(textBoxID.Text);
            oc.Name = textBoxName.Text;
            string gg = "update MembershipCategory set name='" + oc.Name + "' where id=" + oc.Id + "";
            aj.SqlExecute(gg);
            MessageBox.Show("UPDATED");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonSreach_Click(object sender, EventArgs e)
        {
            oc.Id = int.Parse(textBoxID.Text);
            string cc = "select * from MembershipCategory where id =" + oc.Id + "";
            aj.SqlExecute(cc);
            dataGridView1.DataSource = aj.showme(cc);
        }

        private void MembershipCategoryForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = aj.showme(ac);
        }
    }
}
