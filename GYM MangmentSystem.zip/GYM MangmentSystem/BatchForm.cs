﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_MangmentSystem
{
    
    public partial class BatchForm : Form
    {
        Batch oa;
        SqlRunClass aj;
        string ac;
        public BatchForm()
        {
            InitializeComponent();
            oa= new Batch();
            aj = new SqlRunClass();
            ac = "select *from Batch";
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            oa.Id = int.Parse(textBoxId.Text);
            oa.Name = textBoxName.Text;
            string sqlText = @"insert into  Batch ([id],[name])values (" + oa.Id + ",'" + oa.Name + "')";
            aj.SqlExecute(sqlText);
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            oa.Id = int.Parse(textBoxId.Text);
            String sg = "Delete From Batch where id = " + oa.Id + "";
            aj.SqlExecute(sg);
            MessageBox.Show("ITEM DELETE");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            oa.Id = int.Parse(textBoxId.Text);
            oa.Name = textBoxName.Text;
            string gg = "update Batch set name='" + oa.Name + "' where id=" + oa.Id + "";
            aj.SqlExecute(gg);
            MessageBox.Show("UPDATED");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonSreach_Click(object sender, EventArgs e)
        {
            oa.Id = int.Parse(textBoxId.Text);
            string cc = "select * from  Batch where id =" + oa.Id + "";
            aj.SqlExecute(cc);
            dataGridView1.DataSource = aj.showme(cc);
        }

        private void BatchForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = aj.showme(ac);
        }
    }
}
