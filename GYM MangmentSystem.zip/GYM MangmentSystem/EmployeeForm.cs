﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace GYM_MangmentSystem
{
    public partial class EmployeeForm : Form
    {
        
        Employee ob;
        SqlRunClass aj ;
        string ac ;
        Batch og;
        public EmployeeForm()
        {
            InitializeComponent();
            ob = new Employee();
            aj = new SqlRunClass();
            og = new Batch();
            ac = "select *from Employee";
        }

        
        
        private void buttonSave_Click(object sender, EventArgs e)
        {
            ob.Id = int.Parse(textBoxId.Text);
            ob.lastName = textBoxLastName.Text;
            ob.firstName = textBoxFirstName.Text;
            ob.Address = textBoxAddress.Text;
            ob.MobileNo = textBoxMobileNo.Text;
            ob.Dateofbirth = DateTime.Parse(dateTimePickerDateofBirth.Text);
            ob.Gender = textBoxGender.Text;
            ob.Email = textBoxEmail.Text;
            ob.Designation = textBoxDesignation.Text;
            ob.Joinigdate = DateTime.Parse(dateTimePickerjoiningDate.Text);
            og.Name = textBoxBatch.Text;
            string sqlText = @"insert into Employee([id] 
           ,[lastname]
           ,[firstname]
          ,[mobilenumber]
           ,[dateofbirth]
           ,[adress]
           ,[designation]
           ,[joiningdate]
           ,[email]
            ,[batch]
            ,[gender])
          values(" + ob.Id +", '"+ob.lastName+"', '"+ob.firstName+"', '"+ob.MobileNo+"'" +
          ", '"+ob.Dateofbirth+"', '"+ ob.Address + "', '"+ob.Designation+ "', '" + ob.Joinigdate + "', '" + ob.Email+"','"+og.Name+"', '" + ob.Gender + "')";
            aj.SqlExecute(sqlText);
            dataGridView1.DataSource = aj.showme(ac);
            

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            ob.Id = int.Parse(textBoxId.Text);
            String sg = "Delete From Employee where id = "+ob.Id+"";
            aj.SqlExecute(sg);
            MessageBox.Show("ITEM DELETE");
            dataGridView1.DataSource = aj.showme(ac);


        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            ob.Id = int.Parse(textBoxId.Text);
            ob.lastName = textBoxLastName.Text;
            ob.firstName = textBoxFirstName.Text;
            ob.Address = textBoxAddress.Text;
            ob.MobileNo = textBoxMobileNo.Text;
            ob.Dateofbirth = DateTime.Parse(dateTimePickerDateofBirth.Text);
            ob.Gender = textBoxGender.Text;
            ob.Email = textBoxEmail.Text;
            ob.Designation = textBoxDesignation.Text;
            ob.Joinigdate = DateTime.Parse(dateTimePickerjoiningDate.Text);
            og.Name = textBoxBatch.Text;
            string gg= "update Employee set lastname='"+ob.lastName+"',firstname='"+ob.firstName+"',mobilenumber='"+ ob.MobileNo+"'," +
            " dateofbirth='"+ob.Dateofbirth+"',adress='"+ob.Address+"',designation = '"+ob.Designation+"',email = '"+ob.Email+"'," +
         " joiningdate = '"+ob.Joinigdate+"', batch ='"+og.Name+ "' where id ="+ob.Id+" ";
            aj.SqlExecute(gg);
            MessageBox.Show("UPDATED");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            ob.Id = int.Parse(textBoxId.Text);
            string cc= "select * from Employee where id ="+ob.Id+"";
            aj.SqlExecute(cc);
            dataGridView1.DataSource = aj.showme(cc);
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = aj.showme(ac);
        }
    }
}
