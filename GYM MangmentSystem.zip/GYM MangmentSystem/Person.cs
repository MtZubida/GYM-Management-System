﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYM_MangmentSystem
{
    class Person
    {
        private int id;
        private string lastname;
        private string firstname;
        private string gender;
        private DateTime dateofbirth;
        private string email;
        private string mobileno;
       
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string lastName
        {
            get { return lastname; }
            set { lastname = value; }

        }
        public string firstName
        {
            get { return firstname; }
            set { firstname = value; }
        }
        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        public DateTime Dateofbirth
        {
            get { return dateofbirth; }
            set { dateofbirth = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string MobileNo
        {
            get { return mobileno; }
            set { mobileno = value; }
        }
       
    }
}
