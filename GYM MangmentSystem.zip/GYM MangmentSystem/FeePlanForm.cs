﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_MangmentSystem
{
    public partial class FeePlanForm : Form
    {
        FeePlan od;
        SqlRunClass aj ;
        string ac;
        public FeePlanForm()
        {
            InitializeComponent();
            od = new FeePlan();
            aj = new SqlRunClass();
            ac = "select *from FeePlan";
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            od.Name = textBoxFeeplanName.Text;
            od.Id =int.Parse(textBoxFeeplanId.Text);
            od.Amount = textBoxAmount.Text;
            string sqlText = @"insert into FeePlan([id]
            ,[name]
             ,[amount])
               values(" + od.Id + ",'" + od.Name + "','" + od.Amount + "')";
            aj.SqlExecute(sqlText);
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            od.Id = int.Parse(textBoxFeeplanId.Text);
            String sg = "Delete From FeePlan where id = " + od.Id + "";
            aj.SqlExecute(sg);
            MessageBox.Show("ITEM DELETE");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            od.Id = int.Parse(textBoxFeeplanId.Text);
            od.Name = textBoxFeeplanName.Text;
            od.Amount = textBoxAmount.Text;
            string gg = "update FeePlan set name='" + od.Name + "',amount='"+od.Amount+"' where id=" + od.Id + "";
            aj.SqlExecute(gg);
            MessageBox.Show("UPDATED");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonSreach_Click(object sender, EventArgs e)
        {
            od.Id = int.Parse(textBoxFeeplanId.Text);
            string cc = "select * from FeePlan where id =" + od.Id + "";
            aj.SqlExecute(cc);
            dataGridView1.DataSource = aj.showme(cc);
        }

        private void FeePlanForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = aj.showme(ac);
        }
    }
}
